function Ordering() {
    var customerName = document.getElementById("customerName").value;
    var customerAddress = document.getElementById("customerAddress").value;

    var pizzaStyle = document.getElementById("pizzaStyle").value;
    var pizzaSize = document.getElementById("pizzaSize").value;

    var deliveryOpt = document.querySelector('input[name="deliveryOption"]:checked').value;

    var toppingSelection = "";

    for (x=1; x<=4; x++) {
        if (document.querySelector('input[name=toppings' + x + ']:checked')) {
            toppingSelection = toppingSelection + document.getElementById("topping"+ x).value + " ";
        }
    }   

    alert("Customer Name:" + customerName +
          "\nCustomer Address: " + customerAddress +
          "\nPizza Style: " + pizzaStyle +
          "\nPizza Size: " + pizzaSize +
          "\nToppings: " + toppingSelection +
          "\nDelivery Option: " + deliveryOpt  );
    if (deliveryOpt == "Delivery") {
        alert("Your pizza will be delivered within 45 minutes.");
    }

    document.write("Your order has been placed! If any issues or corrections arise please call: 1-570-383-3848");
}

