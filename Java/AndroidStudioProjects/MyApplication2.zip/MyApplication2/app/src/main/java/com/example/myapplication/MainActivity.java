package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    //Class Members
    private static final String TAG = "MainActivity";
    private static final String DATABASE_NAME = "FeedreaderDBHelper.db";

    //Data Members
    FeedReaderDBHelper feedReaderDBHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


    }


}